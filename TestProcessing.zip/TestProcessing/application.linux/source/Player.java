import processing.core.*;

public class Player  {
	int bulletInterval;
	int ground;
	int lives;
	float x, y;
	float angle;
	float speed;
	PVector pos;
	PVector MoveObj;
	PApplet papplet;

	
	
	
	Player(PApplet p)
	  {
		papplet = p;  
	    x = papplet.width/2;
	    y = papplet.height- 10;
	    angle = 0;
		lives = 15;
		speed = 3;
		ground = papplet.height - 20;
		bulletInterval = 35;
	    pos = new PVector(x, y);
	    MoveObj = new PVector(0, 0);
	  }


	boolean canjump = true;
	
	
	public void render() {
		papplet.pushMatrix();
		papplet.translate(pos.x, pos.y);
		papplet.rotate(0);
		papplet.fill(0);
		papplet.ellipse(0, 0, 20, 20);
		// rect(0, 0, 20, 20);
		papplet.text(lives, 0, -10);
		papplet.popMatrix();

		update();
	}

	int limit;
	
	public void update() {
		if (keys['A']) {
			pos.x -= speed;
			angle = PApplet.TWO_PI - PApplet.PI / 2;
		}

		if (keys['D']) {
			pos.x += speed;
			angle = PApplet.PI / 2;
		}

		if (keys['W'] && canjump) {// need a proper jump code
			pos.y -= speed + 100;
			limit += speed + 100;
			if (limit >= speed + 100) {
				canjump = false;
			}
		} else if (!canjump) {
			pos.y += 2;
			if (pos.y >= papplet.height - 11) {
				canjump = true;
				limit = 0;
			}
		}

		// if (keys['S'])
		// {
		// pos.y += speed;
		// }

		if (keys[' '] && bulletInterval > 30) {
			Bullet bullet = new Bullet(papplet);
			bullet.pos.x = pos.x;
			bullet.pos.y = pos.y;
			bullet.angle = angle;
			bullets.add(bullet);
			bulletInterval = 0;
		}

		bulletInterval++;

		if (pos.x > papplet.width - 10) {
			pos.x = papplet.width - 10;
		}
		if (pos.x < 10) {
			pos.x = 10;
		}
		if (pos.y > papplet.height - 10) {
			pos.y = papplet.height - 10;
		}
		if (pos.y < 10) {
			pos.y = 10;
		}
	}
}
