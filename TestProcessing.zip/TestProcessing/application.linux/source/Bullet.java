import processing.core.*;

public class Bullet {

	int lives;
	float x, y;
	float angle;
	float speed;
	PVector pos;
	PVector MoveObj;
	PApplet papplet;

	Bullet(PApplet p) {
		papplet = p;
		x = papplet.width / 2;
		y = papplet.height - 10;
		angle = 0;
		speed = 5;
		pos = new PVector(0, 0);
		MoveObj = new PVector(0, 0);

	}

	public void render() {
		papplet.pushMatrix();
		papplet.translate(pos.x, pos.y);
		papplet.rotate(angle);
		papplet.line(0, 0, 0, 5);
		papplet.popMatrix();

		update();
	}

	void update() {
		MoveObj.x = PApplet.sin(angle);
		MoveObj.y = PApplet.cos(angle);
		MoveObj.mult(speed);
		pos.add(MoveObj);

		if (pos.x < 0 || pos.y < 0 || pos.x > papplet.width || pos.y > papplet.height) {
			bullets.remove(this);
		}
	}
}
