
import processing.core.*;
import java.util.ArrayList;;
public class MyProcessingSketch extends PApplet {

	ArrayList<Player> player = new ArrayList<Player>();
	ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	boolean[] keys = new boolean[512];

	public void settings() {
		size(1000, 500);
	}

	public void setup() {
		player.add(new Player(this));
	}

	public void draw() {
		background(255);
		Player one = player.get(0);
		one.render();

		for (int i = bullets.size() - 1; i >= 0; i--) {
			bullets.get(i).render();
		}
	}
	
	public void keyPressed()
	{
	  keys[keyCode] = true;
	}

	public void keyReleased()
	{
	  keys[keyCode] = false;
	}

	public static void main(String args[]) {
		PApplet.main(new String[] { "--present", "MyProcessingSketch" });
	}

}
